

�� How to build the file of jxl.jar. 

 If you want to make the jxl.jar library, 
 please look over ( go through ) the index.html 

