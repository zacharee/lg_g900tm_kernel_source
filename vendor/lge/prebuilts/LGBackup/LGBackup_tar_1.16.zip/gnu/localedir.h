#define LOCALEDIR "/usr/local/share/locale"
#ifndef DEFAULT_RMT_COMMAND
# define DEFAULT_RMT_COMMAND "/usr/local/libexec/rmt"
#endif
